import React from 'react';
import { Users, ChevronRight } from 'lucide-react';

interface SignInModalProps {
  numUsers: number;
  onComplete: (names: string[]) => void;
}

export default function SignInModal({ numUsers, onComplete }: SignInModalProps) {
  const [names, setNames] = React.useState<string[]>(Array(numUsers).fill(''));
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const inputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    inputRef.current?.focus();
  }, [currentIndex]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentIndex < numUsers - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onComplete(names);
    }
  };

  const handleNameChange = (value: string) => {
    const newNames = [...names];
    newNames[currentIndex] = value;
    setNames(newNames);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full mx-4 transform transition-all">
        <div className="flex items-center gap-3 mb-6">
          <Users className="w-6 h-6 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-800">Trainer Sign-in</h2>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Trainer {currentIndex + 1} of {numUsers}</span>
            <span>{Math.round(((currentIndex + 1) / numUsers) * 100)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / numUsers) * 100}%` }}
            />
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label 
              htmlFor="trainerName" 
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              Enter Trainer Name
            </label>
            <input
              ref={inputRef}
              id="trainerName"
              type="text"
              value={names[currentIndex]}
              onChange={(e) => handleNameChange(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              placeholder="Enter your name"
              required
              minLength={2}
              maxLength={20}
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
          >
            {currentIndex < numUsers - 1 ? (
              <>
                Next Trainer
                <ChevronRight className="w-4 h-4" />
              </>
            ) : (
              'Start Draft'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}