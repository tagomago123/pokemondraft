import React from 'react';
import { Settings, RotateCcw, Edit2 } from 'lucide-react';
import { useDraft } from '../contexts/DraftContext';

interface AdminPanelProps {
  userId: string;
}

export default function AdminPanel({ userId }: AdminPanelProps) {
  const { state, dispatch } = useDraft();
  const [isEditing, setIsEditing] = React.useState<string | null>(null);
  const [editName, setEditName] = React.useState('');

  if (state.admin !== userId) return null;

  const handleUndoLastSelection = (targetUserId: string) => {
    dispatch({ type: 'UNDO_LAST_SELECTION', payload: { userId: targetUserId } });
  };

  const handleUpdateName = (targetUserId: string) => {
    if (editName.trim()) {
      dispatch({
        type: 'UPDATE_USER_NAME',
        payload: { userId: targetUserId, name: editName.trim() },
      });
      setIsEditing(null);
      setEditName('');
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center gap-2 mb-4">
          <Settings className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold">Admin Controls</h3>
        </div>

        <div className="space-y-4">
          {state.users.map((user) => (
            <div key={user.id} className="flex items-center gap-2">
              {isEditing === user.id ? (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="px-2 py-1 border rounded"
                    placeholder={user.name}
                  />
                  <button
                    onClick={() => handleUpdateName(user.id)}
                    className="px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setIsEditing(null)}
                    className="px-2 py-1 bg-gray-200 rounded hover:bg-gray-300"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <>
                  <span className="font-medium">{user.name}</span>
                  <button
                    onClick={() => {
                      setIsEditing(user.id);
                      setEditName(user.name);
                    }}
                    className="p-1 text-gray-600 hover:text-blue-600"
                    title="Edit name"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  {user.selections.length > 0 && (
                    <button
                      onClick={() => handleUndoLastSelection(user.id)}
                      className="p-1 text-gray-600 hover:text-blue-600"
                      title="Undo last selection"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  )}
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}