import React from 'react';
import Select from 'react-select';
import { Pokemon } from '../types';

interface PokemonSelectProps {
  onSelect: (pokemon: Pokemon) => void;
}

export default function PokemonSelect({ onSelect }: PokemonSelectProps) {
  const [options, setOptions] = React.useState<Pokemon[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  React.useEffect(() => {
    fetchInitialPokemon();
  }, []);

  const fetchInitialPokemon = async () => {
    try {
      const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=151');
      const data = await response.json();
      const pokemonList = await Promise.all(
        data.results.map(async (pokemon: { name: string; url: string }) => {
          const detailResponse = await fetch(pokemon.url);
          const detail = await detailResponse.json();
          return {
            name: pokemon.name,
            url: pokemon.url,
            sprite: detail.sprites.front_default,
          };
        })
      );
      setOptions(pokemonList);
    } catch (error) {
      console.error('Error fetching Pokemon:', error);
    }
  };

  return (
    <Select
      className="w-full max-w-xs"
      options={options}
      isLoading={isLoading}
      getOptionLabel={(option) => option.name.charAt(0).toUpperCase() + option.name.slice(1)}
      getOptionValue={(option) => option.name}
      onChange={(newValue) => newValue && onSelect(newValue)}
      formatOptionLabel={(pokemon) => (
        <div className="flex items-center gap-2">
          <img
            src={pokemon.sprite}
            alt={pokemon.name}
            className="w-8 h-8"
          />
          <span className="capitalize">{pokemon.name}</span>
        </div>
      )}
    />
  );
}