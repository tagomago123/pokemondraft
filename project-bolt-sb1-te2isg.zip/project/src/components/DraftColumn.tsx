import React from 'react';
import { DraftUser } from '../types';
import { Trophy } from 'lucide-react';

interface DraftColumnProps {
  user: DraftUser;
}

export default function DraftColumn({ user }: DraftColumnProps) {
  return (
    <div className="flex flex-col items-center w-full max-w-xs">
      <div className="w-full bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-yellow-500" />
          <h2 className="text-xl font-bold text-gray-800">{user.name}</h2>
        </div>
        <div className="space-y-2">
          {user.selections.map((pokemon, index) => (
            <div
              key={`${pokemon.name}-${index}`}
              className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg"
            >
              <img
                src={pokemon.sprite}
                alt={pokemon.name}
                className="w-12 h-12"
              />
              <span className="capitalize font-medium text-gray-700">
                {pokemon.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}