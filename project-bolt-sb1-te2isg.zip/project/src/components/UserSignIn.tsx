import React from 'react';
import { Users } from 'lucide-react';
import { useDraft } from '../contexts/DraftContext';

export default function UserSignIn() {
  const { state, dispatch } = useDraft();
  const [name, setName] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && state.users.length < state.maxUsers) {
      dispatch({
        type: 'ADD_USER',
        payload: { name: name.trim(), id: `user-${Date.now()}` },
      });
      setName('');
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 w-full">
      <div className="flex items-center gap-3 mb-6">
        <Users className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Join Draft</h2>
      </div>

      <div className="mb-4">
        <p className="text-gray-600">
          Trainer {state.users.length + 1} of {state.maxUsers}
        </p>
        <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(state.users.length / state.maxUsers) * 100}%` }}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label
            htmlFor="trainerName"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            Enter Your Trainer Name
          </label>
          <input
            id="trainerName"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Your name"
            required
            minLength={2}
            maxLength={20}
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200"
        >
          Join Draft
        </button>
      </form>
    </div>
  );
}