import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';

interface SocketContextType {
  socket: Socket | null;
  roomId: string | null;
  createRoom: () => void;
  joinRoom: (roomId: string) => void;
  error: string | null;
}

const SocketContext = createContext<SocketContextType | null>(null);

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  useEffect(() => {
    const newSocket = io('https://pokemondraft.onrender.com', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 20000,
      autoConnect: true
    });

    newSocket.on('connect', () => {
      console.log('Connected to server');
      setError(null);
      setReconnectAttempts(0);
    });

    newSocket.on('connect_error', (err) => {
      console.error('Connection error:', err);
      setReconnectAttempts((prev) => prev + 1);
      if (reconnectAttempts >= 5) {
        setError('Unable to connect to server. Please check your internet connection and try again.');
      } else {
        setError('Connecting to server...');
      }
    });

    newSocket.on('disconnect', (reason) => {
      console.log('Disconnected from server:', reason);
      if (reason === 'io server disconnect') {
        newSocket.connect();
      }
      setError('Disconnected from server. Attempting to reconnect...');
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [reconnectAttempts]);

  useEffect(() => {
    if (!socket) return;

    const handleRoomCreated = (newRoomId: string) => {
      console.log('Room created:', newRoomId);
      setRoomId(newRoomId);
      setError(null);
    };

    const handleRoomJoined = (state: { roomId: string }) => {
      console.log('Room joined:', state.roomId);
      setRoomId(state.roomId);
      setError(null);
    };

    const handleError = (message: string) => {
      console.error('Server error:', message);
      setError(message);
    };

    socket.on('room_created', handleRoomCreated);
    socket.on('room_joined', handleRoomJoined);
    socket.on('error', handleError);

    return () => {
      socket.off('room_created', handleRoomCreated);
      socket.off('room_joined', handleRoomJoined);
      socket.off('error', handleError);
    };
  }, [socket]);

  const createRoom = () => {
    if (!socket?.connected) {
      setError('Not connected to server. Please try again.');
      return;
    }
    socket.emit('create_room');
  };

  const joinRoom = (roomId: string) => {
    if (!socket?.connected) {
      setError('Not connected to server. Please try again.');
      return;
    }
    socket.emit('join_room', roomId);
  };

  return (
    <SocketContext.Provider value={{ socket, roomId, createRoom, joinRoom, error }}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
}