import React from 'react';
import { Users } from 'lucide-react';
import PokemonSelect from './components/PokemonSelect';
import DraftColumn from './components/DraftColumn';
import UserSignIn from './components/UserSignIn';
import AdminPanel from './components/AdminPanel';
import RoomJoin from './components/RoomJoin';
import { DraftProvider, useDraft } from './contexts/DraftContext';
import { SocketProvider, useSocket } from './contexts/SocketContext';

function DraftApp() {
  const { state, dispatch } = useDraft();
  const { roomId } = useSocket();

  if (!roomId) {
    return <RoomJoin />;
  }

  const handleNumUsersChange = (value: number) => {
    if (state.users.length === 0) {
      dispatch({ type: 'SET_MAX_USERS', payload: value });
    }
  };

  const handlePokemonSelect = (pokemon: any) => {
    const currentUser = state.users[state.currentTurn];
    if (currentUser) {
      dispatch({
        type: 'SELECT_POKEMON',
        payload: { userId: currentUser.id, pokemon },
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Pokémon Draft</h1>
          {state.users.length === 0 && (
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                <label htmlFor="numUsers" className="text-gray-700">
                  Number of Trainers:
                </label>
                <select
                  id="numUsers"
                  value={state.maxUsers}
                  onChange={(e) => handleNumUsersChange(Number(e.target.value))}
                  className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  {[2, 3, 4, 5, 6].map((num) => (
                    <option key={num} value={num}>
                      {num}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {state.users.length > 0 && (
            <div className="max-w-md mx-auto mb-8">
              <div className="text-left mb-2 space-y-1">
                <p className="text-gray-600">
                  Round: <span className="font-semibold">{state.currentRound}</span>
                </p>
                <p className="text-gray-600">
                  Direction: <span className="font-semibold">{state.isReversed ? '⬅️ Reverse' : '➡️ Forward'}</span>
                </p>
                <p className="text-gray-600">
                  Current Turn:{' '}
                  <span className="font-semibold text-blue-600">
                    {state.users[state.currentTurn]?.name}
                  </span>
                </p>
              </div>
              <PokemonSelect onSelect={handlePokemonSelect} />
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {state.users.map((user) => (
            <DraftColumn key={user.id} user={user} />
          ))}
          {state.users.length < state.maxUsers && (
            <UserSignIn />
          )}
        </div>

        {state.users.map((user) => (
          <AdminPanel key={user.id} userId={user.id} />
        ))}
      </div>
    </div>
  );
}

function AppWrapper() {
  return (
    <SocketProvider>
      <DraftProvider>
        <DraftApp />
      </DraftProvider>
    </SocketProvider>
  );
}

export default AppWrapper;