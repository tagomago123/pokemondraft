import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
    credentials: true,
    allowedHeaders: ["Content-Type"]
  },
  transports: ['websocket', 'polling'],
  pingTimeout: 60000,
  pingInterval: 25000
});

// Enable CORS for all routes
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

// Serve static files from the dist directory
app.use(express.static(join(__dirname, '../dist')));

// Handle client-side routing
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, '../dist/index.html'));
});

const rooms = new Map();

const initialState = {
  users: [],
  currentTurn: 0,
  admin: null,
  maxUsers: 2,
  isReversed: false,
  currentRound: 1
};

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('create_room', () => {
    try {
      const roomId = Math.random().toString(36).substring(2, 8).toUpperCase();
      const roomState = { ...initialState, roomId };
      rooms.set(roomId, roomState);
      socket.join(roomId);
      socket.emit('room_created', roomId);
      io.to(roomId).emit('state_updated', roomState);
    } catch (error) {
      console.error('Error creating room:', error);
      socket.emit('error', 'Failed to create room');
    }
  });

  socket.on('join_room', (roomId) => {
    try {
      const room = rooms.get(roomId);
      if (room) {
        socket.join(roomId);
        socket.emit('room_joined', { roomId, ...room });
        io.to(roomId).emit('state_updated', room);
      } else {
        socket.emit('error', 'Room not found');
      }
    } catch (error) {
      console.error('Error joining room:', error);
      socket.emit('error', 'Failed to join room');
    }
  });

  socket.on('draft_action', ({ roomId, action }) => {
    try {
      const currentState = rooms.get(roomId);
      if (!currentState) {
        socket.emit('error', 'Room not found');
        return;
      }

      let newState;
      switch (action.type) {
        case 'ADD_USER': {
          if (currentState.users.length >= currentState.maxUsers) {
            socket.emit('error', 'Room is full');
            return;
          }
          const isFirstUser = currentState.users.length === 0;
          newState = {
            ...currentState,
            users: [...currentState.users, {
              id: action.payload.id,
              name: action.payload.name,
              selections: []
            }],
            admin: isFirstUser ? action.payload.id : currentState.admin
          };
          break;
        }

        case 'SELECT_POKEMON': {
          const userIndex = currentState.users.findIndex(u => u.id === action.payload.userId);
          if (userIndex !== currentState.currentTurn) {
            socket.emit('error', 'Not your turn');
            return;
          }

          const nextTurn = currentState.isReversed
            ? currentState.currentTurn > 0 ? currentState.currentTurn - 1 : 0
            : currentState.currentTurn < currentState.users.length - 1 ? currentState.currentTurn + 1 : currentState.users.length - 1;

          const newIsReversed = currentState.isReversed
            ? currentState.currentTurn === 0 ? false : currentState.isReversed
            : currentState.currentTurn === currentState.users.length - 1 ? true : currentState.isReversed;

          const roundIncrement = currentState.isReversed && currentState.currentTurn === 0 ? 1 : 0;

          newState = {
            ...currentState,
            users: currentState.users.map(user =>
              user.id === action.payload.userId
                ? { ...user, selections: [...user.selections, action.payload.pokemon] }
                : user
            ),
            currentTurn: nextTurn,
            isReversed: newIsReversed,
            currentRound: currentState.currentRound + roundIncrement
          };
          break;
        }

        case 'SET_MAX_USERS': {
          if (currentState.users.length === 0) {
            newState = {
              ...currentState,
              maxUsers: action.payload
            };
          }
          break;
        }

        default:
          return;
      }

      if (newState) {
        rooms.set(roomId, newState);
        io.to(roomId).emit('state_updated', newState);
      }
    } catch (error) {
      console.error('Error processing action:', error);
      socket.emit('error', 'Failed to process action');
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});